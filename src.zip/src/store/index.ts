import { createStore } from 'vuex';
import { collection, doc, updateDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import db from '@/firebase/config';

const store = createStore({
    state: {
        gorevler: [] as any[],
    },

    mutations: {
        async gorevlerGetir(state) {
            state.gorevler = [];
            const gorevlerRef = collection(db, 'gorevler');
            onSnapshot(gorevlerRef, (snapshot) => {
                state.gorevler = snapshot.docs.map((doc) => ({
                    id: doc.id,
                    gorevAd: doc.data().gorevAd,
                    aciklama: doc.data().aciklama,
                    kategori: doc.data().kategori,
                    tarih: new Date(doc.data().tarih),
                    tamamlanma: doc.data().tamamlanma,
                }));
            });
        },
    },

    actions: {
        async gorevlerGetir({ commit }) {
            const gorevlerRef = collection(db, 'gorevler');

            onSnapshot(gorevlerRef, (snapshot) => {
                const gorevler = snapshot.docs.map((doc) => ({
                    id: doc.id,
                    gorevAd: doc.data().gorevAd,
                    aciklama: doc.data().aciklama,
                    kategori: doc.data().kategori,
                    tarih: new Date(doc.data().tarih),
                    tamamlanma: doc.data().tamamlanma,
                }));
                commit('setGorevler', gorevler);
            });
        },

        async gorevTamamla({ commit }, payload) {
            if (!payload.tamamlanma) {
                const gorevRef = doc(db, 'gorevler', payload.id);
                await updateDoc(gorevRef, { tamamlanma: true });
            }
        },

        async gorevTamamlama({ commit }, payload) {
            if (payload.tamamlanma) {
                const gorevRef = doc(db, 'gorevler', payload.id);
                await updateDoc(gorevRef, { tamamlanma: false });
            }
        },

        async gorevSil({ commit }, payload) {
            const gorevRef = doc(db, 'gorevler', payload.id);
            await deleteDoc(gorevRef);
        },
    },

    getters: {
        gelen: (state) => state.gorevler.filter((gorev) => !gorev.tamamlanma),

        bugun: (state) => {
            const simdikiTarih = new Date();
            return state.gorevler.filter((gorev) => {
                const gorevTarihi = new Date(gorev.tarih);
                return (
                    gorevTarihi.getDate() === simdikiTarih.getDate() &&
                    gorevTarihi.getMonth() === simdikiTarih.getMonth() &&
                    gorevTarihi.getFullYear() === simdikiTarih.getFullYear()
                );
            });
        },

        yapilan: (state) => state.gorevler.filter((gorev) => gorev.tamamlanma),

        gecen: (state) => {
            const simdikiTarih = new Date();
            return state.gorevler.filter((gorev) => {
                const gorevTarihi = new Date(gorev.tarih);
                return gorevTarihi < simdikiTarih && !gorev.tamamlanma;
            });
        },

        kategoriyeGoreGorevGetir: (state) => (kategori: any) => {
            return Array.isArray(state.gorevler)
                ? state.gorevler.filter((item: any) => item.kategori === kategori)
                : [];
        },
    },
});

export default store;
