import {IonPage,IonCard,IonCardHeader,IonCardContent,IonCardSubtitle,IonCardTitle,IonTitle,IonIcon,IonFab,IonFabButton,
    IonModal,IonItem,IonText,IonInput, IonDatetime, IonLabel, IonSelectOption, IonSelect, IonTextarea, IonButton, IonButtons, IonBackButton, IonToolbar, IonHeader,
    IonContent, IonList, IonListHeader, IonItemOptions, IonItemOption, IonItemSliding, IonCheckbox
} from '@ionic/vue';

export default {
    IonPage,IonCard,IonCardHeader,IonCardContent,IonCardSubtitle,IonCardTitle,IonTitle,IonIcon,IonFab,IonFabButton,
    IonModal,IonItem,IonText,IonInput,IonDatetime, IonLabel, IonSelectOption,IonSelect,IonTextarea,IonButton,IonButtons, IonBackButton, IonToolbar, IonHeader,
    IonContent, IonList, IonListHeader, IonItemOptions, IonItemOption, IonItemSliding, IonCheckbox
}